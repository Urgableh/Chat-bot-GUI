# Chat-bot-GUI
A graphical user interface to configure and run Urgableh/Twitch-Channel-Point-Redemption-Bot
